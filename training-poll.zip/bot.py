"""Публикует еженедельный опрос с расписанием тренировок в Telegram-группу."""
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
          "августа", "сентября", "октября", "ноября", "декабря"]


def week_period(monday):
    sunday = monday + timedelta(days=6)
    if monday.month == sunday.month:
        return f"с {monday.day} по {sunday.day} {MONTHS[sunday.month - 1]}"
    return (f"с {monday.day} {MONTHS[monday.month - 1]} "
            f"по {sunday.day} {MONTHS[sunday.month - 1]}")


def api(method, **params):
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/{method}",
        data=json.dumps(params).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.load(resp)
    except urllib.error.HTTPError as e:
        sys.exit(f"Telegram вернул ошибку в {method}: {e.read().decode('utf-8')}")
    if not result.get("ok"):
        sys.exit(f"Telegram вернул ошибку в {method}: {result}")
    return result["result"]


def main():
    cfg = json.loads(Path(__file__).with_name("schedule.json").read_text("utf-8"))

    today = datetime.now(ZoneInfo("Europe/Moscow")).date()
    monday = today - timedelta(days=today.weekday())
    question = cfg["question"].format(period=week_period(monday))

    params = {
        "chat_id": os.environ.get("TELEGRAM_CHAT_ID", ""),
        "question": question,
        "options": [{"text": o} for o in cfg["options"]],
        "is_anonymous": False,
        "allows_multiple_answers": True,
    }
    thread_id = os.environ.get("TELEGRAM_THREAD_ID")
    if thread_id:
        params["message_thread_id"] = int(thread_id)

    if os.environ.get("DRY_RUN"):
        print(question)
        for o in cfg["options"]:
            print(" •", o)
        return

    msg = api("sendPoll", **params)
    print(f"Опрос отправлен: {question}")

    if cfg.get("pin"):
        api("pinChatMessage", chat_id=params["chat_id"],
            message_id=msg["message_id"], disable_notification=True)
        print("Опрос закреплён")


if __name__ == "__main__":
    main()
